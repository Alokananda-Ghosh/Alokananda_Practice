package com.cg.ssms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ssms.bean.ScheduledSessions;
import com.cg.ssms.dao.ITrainingDAO;

@Service
@Transactional
public class TrainingServiceImpl implements ITrainingService {
	@Autowired
	ITrainingDAO itd;

	public ITrainingDAO getItd() {
		return itd;
	}

	public void setItd(ITrainingDAO itd) {
		this.itd = itd;
	}

	@Override
	public List<ScheduledSessions> getAll() {
		// TODO Auto-generated method stub
		return itd.getAll();
	}

}
