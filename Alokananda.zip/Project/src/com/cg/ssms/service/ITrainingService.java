package com.cg.ssms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.ssms.bean.ScheduledSessions;


public interface ITrainingService {
	public List<ScheduledSessions> getAll();
}
