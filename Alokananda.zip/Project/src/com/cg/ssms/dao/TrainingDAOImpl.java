package com.cg.ssms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ssms.bean.ScheduledSessions;

@Repository
public class TrainingDAOImpl implements ITrainingDAO {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<ScheduledSessions> getAll() {
		// TODO Auto-generated method stub
		TypedQuery<ScheduledSessions> query = entityManager.createQuery("SELECT t FROM ScheduledSessions t",
				ScheduledSessions.class);
		return query.getResultList();
	}
}
