package com.cg.ssms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.bean.ScheduledSessions;
import com.cg.ssms.service.ITrainingService;

@Controller
public class SessionController {
	@Autowired
	ITrainingService itss;

	public ITrainingService getItss() {
		return itss;
	}
	public void setItss(ITrainingService itss) {
		this.itss = itss;
	}
	@RequestMapping("/ScheduledSessions")
	public ModelAndView scheduled() {
		List<ScheduledSessions> session = itss.getAll();
		return new ModelAndView("ScheduledSessions", "session", session);
	}
	@RequestMapping("/Success")
	public ModelAndView success(@RequestParam("session_name") String session_name) {
		return new ModelAndView("Success","session_name",session_name);	
	}
}
